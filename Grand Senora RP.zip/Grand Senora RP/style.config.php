<?PHP 

// Color settings

$style = array (
'background_color' => "black", 
// Main background color

'text_color' => "white", 
// Main text color

'background_description' => "orange", 
// Description background color

'color_description' => "black", 
// Description text color

'background_footer' => "black", 
// Footer background color

'color_footer' => "orange", 
// Footer text color

);

?>