To get server info, you need to add your server on SeeGaming.com, and get server ID here (https://seegaming.com/panel > My servers)

Open website.config.php, and change your server settings